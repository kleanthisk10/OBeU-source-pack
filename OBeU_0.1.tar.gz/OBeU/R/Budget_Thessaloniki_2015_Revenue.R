#' Revenue Details of Municipality of Thessaloniki for 2015
#'
#' A dataset containing the Budget phase revenue amounts of Municipality of Thessaloniki
#'
#' @format A data frame with 53940 rows and 10 variables:
#' \describe{
#'   \item{Υπηρεσία}{administrative unit-No admin unit in revenue}
#'   \item{Περιγραφή}{ description }
#'   \item{K.A.}{K.A.}
#'   \item{Προϋπολογισθέντα}{ draft }
#'   \item{Διαμορφωθέντα}{ revised }
#'   \item{Βεβαιωθέντα}{ approved }
#'   \item{Εισπρα.θέντα}{ executed }
#' }
#' @source \url{ ... }
"Budget_Thessaloniki_2015_Revenue"
