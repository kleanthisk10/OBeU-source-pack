#' Finding Clusters in an OBEU dataset


#' @param data The input dataset to aggregate
#' @param what A string of dimensions to aggregate (e.g."dim1,dim2" that results in dim1+dim2)
#' @param to A string of dimensions to aggregate (e.g."dim1,dim2" that results in dim1+dim2)
#' @param fun.aggregate The aggregation function (e.g.sum,mean,sd,var,max,min,...,summary,decribe).
#' @param ... Other arguments to pass, see [cast]
#' @param margins The overall in the output data frame
#' @param subset Aggregate a subset of the input data
#' @details Works but still needs more

#' @return A json string with the selected aggregation parameters \code{what} and \code{subset}.
#'
#' @examples
#' #Not an OBeu Example
#' aggregations.obeu(iris,"Species, variable")
############################################################################

cluster.obeu<-function(dataset){
  if(ncol(dataset)<2)
  {
    stop("The dimension (number of columns) of dataset must be at least 2.")
  }


  ####Prepare

  names(dataset)<-c("administrative_unit","expen_code","description",
                    "draft","revised","reserved" ,"approved","executed")
  #Converting to proper numbering format

  indx<-4:ncol(dataset)
  dataset[indx] <- lapply(dataset[indx], function(x) as.numeric(as.character(x)))

  if (length(which(dataset$executed-dataset$approved!=0))==0)

    dataset<-dataset[,1:7]

  names(dataset)<-c("administrative_unit","expen_code","description",
                    "draft","revised","reserved" ,"approved&executed")


  require(reshape)
  meltdata <- melt(dataset)
  subjmeans <- cast(meltdata, administrative_unit+expen_code~variable, sum)
  keeps <- apply(dataset, 1, function(x) { ! ( any(as.numeric(x[7])<1)
  ) } )

  num <- sapply(dataset, is.numeric)
  dataset<-dataset[keeps,]

  #Required Libraries
  require(clValid)
  require(factoextra)

  ##############################################################
  ### Determine the optimal number of clusters
  ##############################################################


  number_of_clusters <- NbClust_featured(dataset[num] ,diss=NULL , distance = 'euclidean',
                                         min.nc = 2, max.nc = 10,
                                         method = "ward.D2", index ="all")

  # Best number of clusters

  number_of_clusters<-number_of_clusters$Best.nc[,-c(29,27)]

  # Function to find the optimal number of clusters
  # according to what most indices proposed.

  get_optnum_clusters <- function(v) {
    uniqv <- unique(v)
    uniqv[which.max(tabulate(match(v, uniqv)))]
  }

  optimal_clustnum <- get_optnum_clusters(number_of_clusters[1,])

  ##############################################################
  ## Clustering Method
  ##############################################################
  options(warn=-1)

  method_clvalid<-clValid(as.matrix(dataset[num]),optimal_clustnum,
                          clMethods=c("hierarchical", "pam"),
                          validation=c("internal","stability"),
                          metric = "euclidean",
                          method="ward")

  selected_methods<-optimalScores(method_clvalid)$Method


  # Create the function to find the optimal number of clusters
  # according to most indices propose.

  getclustMethods <- function(x) {
    freq_table<-table(x)
    names(freq_table[which.max(freq_table)])
  }

  #Extract Best Method

  best_method<-getclustMethods(selected_methods)

  #Implemetation of Best Clustering Method

  model_cl<-eval(parse(text=paste0(best_method,
                                   "(","dataset,optimal_clustnum",")")))


  ##########################################################################
  if(best_method=="hierarchical"){

    hierarchical=hclust(dist(dataset[num]), method = "ward.D2")

    # draw dendogram with red borders around the 5 clusters
    pp<-rect.hclust(fit, k=optimal_clustnum, border="red")

    ##########################################################################
  }else if(best_method=="pam"){

    pam=pam(dataset,optimal_clustnum, metric = "euclidean")

    pp<-clusplot(pam$data,pam$clustering)
  }
  ##########################################################################

  return(pp)
}

