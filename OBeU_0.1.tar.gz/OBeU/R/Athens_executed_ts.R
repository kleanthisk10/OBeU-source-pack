#' Time series of Executed Expenditure Budget Phase of Municipality of Athens
#'
#' A dataset containing the Executed Budget phase expenditure amounts of Municipality of Athens from 2004-2015
#'
#' @format A ts object with 12 Executed amounts from 2004-2015:
#' \describe{
#'   \item{administrative unit}{ ... }
#'   \item{description}{ ... }
#' }

"Athens_executed_ts"
