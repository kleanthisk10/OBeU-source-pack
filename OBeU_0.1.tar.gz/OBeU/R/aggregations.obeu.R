#' Aggregate an OBEU dataset


#' @param data The input dataset to aggregate
#' @param what A string of dimensions to aggregate (e.g."dim1,dim2" that results in dim1+dim2)
#' @param to A string of dimensions to aggregate (e.g."dim1,dim2" that results in dim1+dim2)
#' @param fun.aggregate The aggregation function (e.g.sum,mean,sd,var,max,min,...,summary,decribe).
#' @param ... Other arguments to pass, see [cast]
#' @param margins The overall in the output data frame
#' @param subset Aggregate a subset of the input data
#' @details Works but still needs more

#' @return A json string with the selected aggregation parameters \code{what} and \code{subset}.
#'
#' @examples
#' #Not an OBeu Example
#' aggregations.obeu(iris,"Species, variable")
############################################################################

aggregations.obeu<- function( data,what="...",to_what= "variable",
                              fun.aggregate="sum", ...)
{

  # Melt data
  Sys.setlocale(category = "LC_ALL", locale = "Greek")

  molten_data=reshape2::melt(data )
  names(molten_data)=tolower(names(molten_data))

  ##Formula
  if(missing(what)==F){

    what=  tolower(as.character(substitute(what)))
    what=as.vector(unlist(stringr::str_split(what, pattern = ",")))

    if (what[1]=="c"){what=what[-1]}

    if (all(what %in% names(molten_data))==F){
      print("Please give an appropriate value to what")
      names(molten_data)
      } else {

    what= what[which(what %in% names(molten_data))]
    what=stringr::str_c(what, collapse = "+")

    }
}

  if(missing(to_what)==F){

    to_what=  tolower(as.character(substitute(to_what)))
    to_what=as.vector(unlist(stringr::str_split(to_what, pattern = ",")))

    if (to_what[1]=="c"){to_what=to_what[-1]}

    if (all(to_what %in% names(molten_data))==F){
      print("Please give an appropriate value  to_what")
      names(molten_data)
    } else {

      to_what= to_what[which(to_what %in% names(molten_data))]
      to_what=stringr::str_c(to_what, collapse = "+")

    }
  }

  ##
  expression=stringr::str_c(what,"~", to_what, collapse = " ")

  #Multiple aggregation functions
  fun.aggregate=as.vector(as.character(substitute(fun.aggregate)))
  if (length(fun.aggregate)>1)
  { fun.aggregate=fun.aggregate[-1]}
  result=list()
  for (i in 1:length(fun.aggregate)){
    result[[i]] <-reshape::cast(molten_data, expression,  fun.aggregate[i], ... )
    names(result)[i]<-paste(fun.aggregate)[i]

  }

  #result<-jsonlite::toJSON(result)

  return(result)

}
