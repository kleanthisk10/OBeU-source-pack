#' Time series of Approved Expenditure Budget Phase of Municipality of Athens
#'
#' A dataset containing the Approved Budget phase expenditure amounts of Municipality of Athens from 2004-2015
#'
#' @format A ts object with 12 approved amounts from 2004-2015:
#' \describe{
#'   \item{administrative unit}{ ... }
#'   \item{description}{ ... }
#' }

"Athens_approved_ts"
